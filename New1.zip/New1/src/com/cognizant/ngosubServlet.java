package com.cognizant;

public class ngosubServlet {

}
