package com.cognizant.service;

import java.sql.Array;
import java.sql.SQLException;

import com.cognizant.dao.SubscriptionDao;
import com.cognizant.model.Subscription;

public class SubscriptionService {
	
	
	public static void addSubscription( int ngoid ,String[] postids) throws ClassNotFoundException, SQLException {
		
		SubscriptionDao dao= new SubscriptionDao();
		
		dao.insertSubscription(ngoid,postids);
		
	}
	

}
