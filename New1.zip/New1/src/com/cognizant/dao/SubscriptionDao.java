package com.cognizant.dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.model.Subscription;

public class SubscriptionDao {
	
	
	Connection con=null;
	public void insertSubscription( int ngoid, String[] postsid) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		String[] a=postsid;
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root","root");
		String query="insert into subscription (ngo_id,post_id,status) values(?,?,?)";
		PreparedStatement ps = con.prepareStatement(query);
		for(int i=0;i< postsid.length;i++)
		{
			ps.setInt(1, ngoid);
			ps.setString(2, postsid[i]);
			ps.setString(3, "pending");
			int count = ps.executeUpdate();
			System.out.println(count + " inserted Successfully");

		}
		
			
	

		

}
}
