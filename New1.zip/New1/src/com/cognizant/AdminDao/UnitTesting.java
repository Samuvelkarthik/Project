package com.cognizant.AdminDao;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cognizant.UserDaoImp1.NgoDao;
import com.cognizant.userBean.Ngo;

public class UnitTesting 
{
	@Test
	public void testA() throws Exception
	{
		Ngo n=new Ngo();
		n.setContact(Long.parseLong("12313"));
		n.setDate("09/09/2019");
		n.setEmail("a@gmail.com");
		n.setId("1");
		n.setName("a");
		n.setPassword("a");
		assertEquals(1,NgoDao.saveNGO(n));
	}
}
